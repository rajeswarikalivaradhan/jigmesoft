$(document).ready(function () {

    getQABomRequest();

    var swalWithBootstrapButtons = Swal.mixin({
        buttonsStyling: false
    });

    function alertMessageFunction(mode) {
        if(mode === 'confirmation_save') {
            return {
                title: 'Are you sure want to \n save the details ?',
                text: "If you save You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                scrollbarPadding: false,
                confirmButtonText: 'Yes, do it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true,
                customClass: {
                    'confirmButton': 'btn btn-green mx-2 px-3',
                    'cancelButton': 'btn btn-red mx-2 px-3'
                }
            }
        }
         
        if(mode == "saved") {
            return {
                title: 'Saved!',
                text: 'Operation completed successfully.',
                type: 'success',
                icon: 'success',
                customClass: {
                    'confirmButton': 'btn btn-info px-5'
                }
            }
        }
        
        if(mode == "cancelled") {
            return {
                title: 'Cancelled',
                text: 'Cancelled successfully.',
                type: 'error',
                icon: 'error',
                customClass: {
                    'confirmButton': 'btn btn-secondary px-5'
                }
            }
        }
        
        if(mode == "validation_error") {
            return {
                title: 'Warning',
                text: "Please fill all free text and select fields",
                icon: 'warning',
                confirmButtonText: 'OK',
                customClass: {
                    'confirmButton': 'btn btn-secondary px-5'
                }
            }
        }
        
        if(mode == "selecterror") {
            return {
                title: 'Warning',
                text: "Please select atleast one requirement",
                icon: 'warning',
                confirmButtonText: 'OK',
                customClass: {
                    'confirmButton': 'btn btn-secondary px-5'
                }
            }
        }

        if(mode == "confirmation") {
            return {
                title: 'Are you sure want to \n move the details ?',
                text: "If you save You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                scrollbarPadding: false,
                confirmButtonText: 'Yes, do it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true,
                customClass: {
                    'confirmButton': 'btn btn-green mx-2 px-3',
                    'cancelButton': 'btn btn-red mx-2 px-3'
                }
            }
        }
    }

    
    SUMCOL = function(instance, columnId, twoColumn) {
        var total = 0;
        var id = 1;
        for (var j = 0; j < instance.options.data.length; j++) {
            if(twoColumn == 'twoColumn')
            {
                id = 2;
            }
            if (Number(instance.records[j][columnId - id].innerHTML)) {
                total += Number(instance.records[j][columnId - id].innerHTML);
            }
        }
        total = numeral(total).format('0');
        total = (total > 0) ? total : '';
        return total;
    }


    GPWSUMCOL = function(instance, columnId) {
        var total = 0;
        for (var j = 0; j < instance.options.data.length; j++) {
            if (Number(instance.records[j][columnId - 1].innerHTML)) {
                total += Number(instance.records[j][columnId - 1].innerHTML);
            }
        }
        total = numeral(total).format('0.000');
        total = (total > 0) ? total : ''
        return total;
    }
     
    function footer(grid_name)
    {
        if(grid_name == 'in-house')
        {
            return [[ '', '', '', '', '', '', '', '', '', '', '','Total:', '=GPWSUMCOL(TABLE(), COLUMN(), "")', '', '=GPWSUMCOL(TABLE(), COLUMN(), "")', '=GPWSUMCOL(TABLE(), COLUMN(), "")']];
        }
        else if(grid_name == 'mi-issued')
        {
            return [[ '', '', '', '', '', 'Total:', '=GPWSUMCOL(TABLE(), COLUMN(), "")', '', '', '=GPWSUMCOL(TABLE(), COLUMN(), "")', '=GPWSUMCOL(TABLE(), COLUMN(), "")', '=GPWSUMCOL(TABLE(), COLUMN(), "")', '', '', '', '']];
        }
    }

    // *********************************************************************************************************************************** 
    // Purchase REQUEST STARTS HERE 
    // ***********************************************************************************************************************************

    function getQABomRequest() {
        var data = new FormData();
        data.append('enquiry_id', enquiry_id);
        data.append('reqId', reqId);
        data.append('itemCode', itemCode);
        let request = $.ajax({
            type: "POST",
            url: base_path + 'request/Bomrequest/getOrderStockDetails',
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            success: function (data) {
                bom_requirement_data = JSON.parse(data);

                let link = base_path + 'request/Bomrequest/draftdc/'+encodeURIComponent(btoa(enquiry_id))+'/reqId/'+encodeURIComponent(btoa(reqId))+'/miId/'+encodeURIComponent(btoa(bom_requirement_data.miId));

                $("#draftLink").attr("href", link);

                append_in_house_details(bom_requirement_data);
                append_item_accept_status(bom_requirement_data);
                append_in_house_consolidated_qty(bom_requirement_data);
                append_shipment_details(bom_requirement_data);
            },
            error: function () {
                console.log("Error");
            }
        });
    }

    function append_in_house_details(data) {
        $('#inHouseQty').html('');
        let list = {
            data: data.inhousestatusdetails,
            columns: [
                { title:'mode', width:'0%',align:'center',type:'hidden'},
                { title:'id', width:'0%',align:'center',type:'hidden'},
                { type: 'dropdown', title: 'Item Description', width: '8%', align: 'left', source: data.itemDescription, readOnly: true },
                { type: 'text', title: 'Blend (%) / Content / \n Material', width: '8%', align: 'left', readOnly: true },
                { type: 'dropdown', title: 'Garment\n Size', width: '8%', align: 'left', source: data.garmentSize, filter: sizeFilter, readOnly: true },
                { type: 'dropdown', title: 'Item Code', width: '8%', align: 'left', source: data.itemCode, filter: itemFilter, readOnly: true },
                { type: 'dropdown', title: 'Item Colour Code', width: '8%', align: 'left', source: data.itemColorCode, filter: colorFilter, readOnly: true },
                { type: 'dropdown', title: 'Size / \n Dimension', width: '7%', align: 'center', source: data.sizeDia, filter: diaFilter, readOnly: true },
                { type: 'dropdown', title: 'UOM', width: '7%', align: 'center', source: data.uom, filter: uomFilter, readOnly: true },
                { title: 'P.I. Ref. No.', width: '15%', align: 'center', type: 'dropdown', source: data.piRefNo, filter: refNoFilter, readOnly: true },

                { title: 'Invoice No.', width: '15%', align: 'center', readOnly: true },
                { title: 'Invoice\n Date', width: '15%', align: 'center', readOnly: true },
                { title: 'Invoice Qty.', width: '15%', align: 'center', readOnly: true },
                { title: 'Rate Per Unit\n (Rs.)', width: '15%', align: 'center', readOnly: true },
                { title: 'Invoice Value\n (Rs.)', width: '15%', align: 'center', readOnly: true },
                
                { title: 'Received Qty.', width: '8%', align: 'right', readOnly: true },
                { title: 'UOM', width: '5%', align: 'center', type: 'dropdown', source: data.uomData, readOnly: true },
                { title: 'Received Date', width: '6%', align: 'center', type: 'calendar', options: { format: 'DD/MM/YYYY' }, readOnly: true },
                { title: 'Storage Bin / Bag / \n Rack Ref. No.', width: '6%', align: 'center', type: 'text', readOnly: true },
            ],
            minDimensions: [4, 1],
            allowDeleteColumn: false,
            allowInsertRow: true,
            allowInsertColumn: false,
            footers: footer('in-house'),
            // updateTable: function(instance, cell, col, row, val, label) {
            //     if(col == 11)
            //     {
            //         txtValue = numeral(val).format('0.000');
            //         $(cell).text(txtValue);
            //         instance.jexcel.options.data[row][col] = txtValue;
            //     }
            // }
        };

        inHouseQty_vm = new Vue({
            el: '#inHouseQty',
            mounted: function () {
                let spreadsheet = jexcel(this.$el, list);
                Object.assign(this, spreadsheet);
            },
        });
    }

    // FILTER STARTS //

    function sizeFilter(instance, cell, c, r, source) {
        var item_id = instance.jexcel.getValueFromCoords(c - 1, r);
        if (item_id !== "") {
            return source.filter(function (val) {
                if (val.item_id == item_id) return true;
            })
        } else {
            return [];
        }
    }

    function itemFilter(instance, cell, c, r, source) {
        var size_id = instance.jexcel.getValueFromCoords(c - 1, r);
        var item_id = instance.jexcel.getValueFromCoords(c - 2, r);
        if (item_id !== "") {
            return source.filter(function (val) {
                if (val.item_id == item_id && val.size_id == size_id) return true;
            })
        } else {
            return [];
        }
    }

    function colorFilter(instance, cell, c, r, source) {
        var item_code_id = instance.jexcel.getValueFromCoords(c - 1, r);
        var size_id = instance.jexcel.getValueFromCoords(c - 2, r);
        var item_id = instance.jexcel.getValueFromCoords(c - 3, r);
        if (item_id !== "") {
            return source.filter(function (val) {
                if (val.item_id == item_id && val.size_id == size_id && val.item_code_id == item_code_id) return true;
            })
        } else {
            return [];
        }
    }

    function diaFilter(instance, cell, c, r, source) {
        var color_id = instance.jexcel.getValueFromCoords(c - 1, r);
        var item_code_id = instance.jexcel.getValueFromCoords(c - 2, r);
        var size_id = instance.jexcel.getValueFromCoords(c - 3, r);
        var item_id = instance.jexcel.getValueFromCoords(c - 4, r);
        if (item_id !== "") {
            return source.filter(function (val) {
                if (val.item_id == item_id && val.size_id == size_id && val.item_code_id == item_code_id 
                    && val.color_id == color_id) 
                return true;
            })
        } else {
            return [];
        }
    }

    function uomFilter(instance, cell, c, r, source) {
        var dia_id = instance.jexcel.getValueFromCoords(c - 1, r);
        var color_id = instance.jexcel.getValueFromCoords(c - 2, r);
        var item_code_id = instance.jexcel.getValueFromCoords(c - 3, r);
        var size_id = instance.jexcel.getValueFromCoords(c - 4, r);
        var item_id = instance.jexcel.getValueFromCoords(c - 5, r);
        if (item_id !== "") {
            return source.filter(function (val) {
                if (val.item_id == item_id && val.size_id == size_id && val.item_code_id == item_code_id 
                    && val.color_id == color_id && val.dia_id == dia_id) 
                return true;
            })
        } else {
            return [];
        }
    }

    function refNoFilter(instance, cell, c, r, source) {
        var uom_id = instance.jexcel.getValueFromCoords(c - 1, r);
        var dia_id = instance.jexcel.getValueFromCoords(c - 2, r);
        var color_id = instance.jexcel.getValueFromCoords(c - 3, r);
        var item_code_id = instance.jexcel.getValueFromCoords(c - 4, r);
        var size_id = instance.jexcel.getValueFromCoords(c - 5, r);
        var item_id = instance.jexcel.getValueFromCoords(c - 6, r);
        if (item_id !== "") {
            return source.filter(function (val) {
                if (val.item_id == item_id && val.size_id == size_id && val.item_code_id == item_code_id 
                    && val.color_id == color_id && val.dia_id == dia_id && val.uom_id == uom_id)
                return true;
            })
        } else {
            return [];
        }
    }

    // FILTER ENDS //

    function append_item_accept_status(data) {

        $('#miIndentReceived').html('');
        let list = {
            data: data.miindentreceiveddetails,
            columns: [
                { title:'id', width:'0%',align:'center',type:'hidden'},
                { type: 'text', title: 'M.I. Ref. No.', width: '6%', align: 'left', readOnly: true },
                { type: 'text', title: 'M.I. Request \n Date & Time', width: '6%', align: 'left', readOnly: true },
                { type: 'text', title: 'M.I. Cutoff \n Date & Time', width: '6%', align: 'left', readOnly: true },
                { type: 'text', title: 'P.O. No.', width: '6%', align: 'left', readOnly: true },
                { title: 'Combo', width: '15%', align: 'left', readOnly: true },
                { title: 'Component', width: '6%', align: 'left', readOnly: true, options: { format: 'DD/MM/YYYY' } },
                { title: 'Colour', width: '6%', align: 'left', readOnly: true },
                { title: 'Size Spec Code', width: '6%', align: 'center', readOnly: true, options: { format: 'DD/MM/YYYY' } },
                { title: 'Purpose', width: '8%', align: 'center', readOnly: true },
                { title: 'M.I. Type \n Interna / External', width: '8%', align: 'center', type: 'text', readOnly: true },
                { title: 'Issued to Dept. / \n Vendor Name', width: '8%', align: 'center', readOnly: true },
                { title: 'M.I. Qty.', width: '8%', align: 'right', type: 'text', readOnly: true },
                { title: 'UOM', width: '8%', align: 'center', readOnly: true },
            ],
            minDimensions: [4, 1],
            allowDeleteColumn: false,
            allowInsertRow: false,
            allowInsertColumn: false,
            updateTable: function(instance, cell, col, row, val, label) {
                if(col == 12)
                {
                    txtValue = numeral(val).format('0.000');
                    $(cell).text(txtValue);
                    instance.jexcel.options.data[row][col] = txtValue;
                }
            }
        };

        miIndentReceived_vm = new Vue({
            el: '#miIndentReceived',
            mounted: function () {
                let spreadsheet = jexcel(this.$el, list);
                Object.assign(this, spreadsheet);
            },
        });
    }

    function append_in_house_consolidated_qty(data) {

        let issuedDD = [ 'PART', 'FULL' ];

        let miissueddetails = data.miissueddetails;

        $('#matrerialIssuedDetails').html('');
        let list = {
            data: miissueddetails,
            columns: [
                { title:'mode', width:'0%',align:'center',type:'hidden'},
                { title:'id', width:'0%',align:'center',type:'hidden'},
                { type: 'text', title: 'M.I. Ref. No.', width: '8%', align: 'left', source: data.MIRefNo },
                { type: 'text', title: 'Issued to Dept. / \n J.W. Vendor Name', width: '6%', align: 'left', readOnly: true },
                { type: 'text', title: 'D.C. No.', width: '6%', align: 'left', readOnly: true },
                { type: 'text', title: 'D.C. \n Date & Time', width: '6%', align: 'left', readOnly: true },
                { title: 'Issued Qty.', width: '5%', align: 'right' },
                { title: 'Issued in \n Part / Full', width: '5%', align: 'center', 'type': 'dropdown', source: issuedDD },
                { title: 'M.I. \n Pending Qty.', width: '5%', align: 'right', readOnly: true },
                { title: 'Returned \n Defective Qty.', width: '5%', align: 'right' },
                { title: 'Replaced \n Defective Qty.', width: '5%', align: 'right' },
                { title: 'Returned \n Excess Qty.', width: '5%', align: 'right' },
                { title: 'Total \n Available Qty.', width: '5%', align: 'center', readOnly: true },
                { title: 'UOM', width: '5%', align: 'center', readOnly: true },
                { title: 'Average Rate Per Unit (Rs.)', width: '5%', align: 'center', readOnly: true },
                { title: 'Balance Stock Value (Rs.)', width: '5%', align: 'center', readOnly: true },
            ],
            minDimensions: [4, 1],
            allowDeleteColumn: false,
            allowInsertRow: true,
            allowInsertColumn: false,
            footers: footer('mi-issued'),
            updateTable: function(instance, cell, col, row, val, label) {
                if(col == 2)
                {
                    mi_id = val;
                }
                if(col == 6)
                {
                    qty = val;
                    txtValue = numeral(qty).format('0.000');
                    $(cell).text(txtValue);
                    instance.jexcel.options.data[row][col] = txtValue;
                }
                if(col == 8) {

                    let miindentreceiveddetails = data.miindentreceiveddetails;

                    let tot_pen_qty = 0;

                    let issued_qty = 0;

                    for (let i = 0; i < miindentreceiveddetails.length; i++) {
                        if(miindentreceiveddetails[i][0] == mi_id) {
                            tot_pen_qty = miindentreceiveddetails[i][12];
                        }
                    }

                    for (let i = 0; i < row+1; i++) {
                        if(miissueddetails[i][2] == mi_id)
                        {
                            issued_qty += parseFloat(miissueddetails[i][6]);
                        }
                    }

                    issued_qty = numeral(issued_qty).format('0.000');

                    p_qty = tot_pen_qty - issued_qty;

                    txtValue = numeral(p_qty).format('0.000');

                    if(tot_pen_qty > 0)
                    {
                        $(cell).text(txtValue);
                        instance.jexcel.options.data[row][col] = txtValue;
                    }

                }
                if(col == 9) {
                    return_qty = val;
                    txtValue = numeral(return_qty).format('0.000');
                    $(cell).text(txtValue);
                    instance.jexcel.options.data[row][col] = txtValue;
                }
                if(col == 10) {
                    replace_qty = val;
                    txtValue = numeral(replace_qty).format('0.000');
                    $(cell).text(txtValue);
                    instance.jexcel.options.data[row][col] = txtValue;
                }
                if(col == 11) {
                    return_qty = val;
                    txtValue = numeral(return_qty).format('0.000');
                    $(cell).text(txtValue);
                    instance.jexcel.options.data[row][col] = txtValue;
                }
                if(col == 12) {
                    if(row == 0)
                    {
                        r_qty = numeral(data.receivedQty).format('0.000');
                    }
                    total_qty = parseFloat(r_qty) - parseFloat(qty) - parseFloat(replace_qty) + parseFloat(return_qty);
                    txtValue = numeral(total_qty).format('0.000');
                    $(cell).text(txtValue);
                    instance.jexcel.options.data[row][col] = txtValue;
                    r_qty = txtValue;
                }
            }
        };

        mateiralIssuedDetails_vm = new Vue({
            el: '#matrerialIssuedDetails',
            mounted: function () {
                let spreadsheet = jexcel(this.$el, list);
                Object.assign(this, spreadsheet);
            },
        });
    }

    function append_shipment_details(data) {

        let statusData = [
            { 'id': "0", 'name': 'PENDING' },
            { 'id': "1", 'name': 'APPROVED' },
            { 'id': "2", 'name': 'DISCREPANCY' }
        ];

        let orderStatusData = [
            { 'id': "0", 'name': 'PENDING' },
            { 'id': "1", 'name': 'APPROVED' },
            { 'id': "2", 'name': 'DISCREPANCY' }
        ];

        let stockData = [
            { 'id': "0", 'name': 'PENDING' },
            { 'id': "1", 'name': 'MOVED TO SSL' }
        ];
        
        let houseData = inHouseQty_vm.getData();
        let materialissuedData = mateiralIssuedDetails_vm.getData();
        let uom = '';
        let tol_rece_qty = tol_issued_qty = tol_defective_qty = defective_qty_replace = tol_excess_qty = tol_available_qty = 0;
        for (let i = 0; i < houseData.length; i++) {
            tol_rece_qty += parseFloat(houseData[i][11]);
        }

        for (let i = 0; i < materialissuedData.length; i++) {
            tol_issued_qty += parseFloat(materialissuedData[i][6]);
            tol_defective_qty += parseFloat(materialissuedData[i][9]);
            defective_qty_replace += parseFloat(materialissuedData[i][10]);
            tol_excess_qty += parseFloat(materialissuedData[i][11]);
            uom = materialissuedData[0][13];
            if(i == materialissuedData.length - 1)
            {
                tol_available_qty += parseFloat(materialissuedData[i][12]);
            }
        }

        $('#shipmentOrderClosure').html('');
        let list = {
            data: data.shipmentorderclosuredetails,
            columns: [
                { title:'id', width:'0%',align:'center',type:'hidden'},
                { type: 'dropdown', title: 'Final Shipment \n Status', width: '8%', align: 'left', source: statusData },
                { type: 'calendar', title: 'Final Shipment \n Ex-factory Date & Time', width: '6%', align: 'center', options: { format:'DD/MM/YYYY HH12:MI AM/PM', time:1 } },
                { type: 'text', title: 'Total \n Received Qty.', width: '6%', align: 'right', readOnly: true },
                { type: 'text', title: 'Total \n Issued Qty.', width: '6%', align: 'right', readOnly: true },
                { title: 'Total \n Defective Qty.', width: '5%', align: 'right', readOnly: true },
                { title: 'Total Defective \n Qty.Replaced', width: '5%', align: 'right', readOnly: true },
                { title: 'Total Excess \n Qty. Returned ', width: '5%', align: 'right', readOnly: true },
                { title: 'Total \n Available Qty.', width: '5%', align: 'right', readOnly: true },
                { title: 'UOM', width: '5%', align: 'center', readOnly: true },
                { title: 'Order Closure \n Status', width: '5%', align: 'center', type: 'dropdown', source: orderStatusData },
                { title: 'Order Closure \n Date & Time', width: '5%', align: 'center', type: 'calendar', options: { format:'DD/MM/YYYY HH12:MI AM/PM', time:1 } },
                { title: 'Available Stock \n Status', width: '5%', align: 'center', type: 'dropdown', source: stockData },
                { title: 'Status Update \n Date & Time', width: '5%', align: 'center', readOnly: true },
            ],
            minDimensions: [4, 1],
            allowDeleteColumn: false,
            allowInsertRow: false,
            allowInsertColumn: false,
            updateTable: function(instance, cell, col, row, val, label) {
                if(col == 3)
                {
                    txtValue = numeral(tol_rece_qty).format('0.000');
                    $(cell).text(txtValue);
                    instance.jexcel.options.data[row][col] = txtValue;
                }
                if(col == 4)
                {
                    txtValue = numeral(tol_issued_qty).format('0.000');
                    $(cell).text(txtValue);
                    instance.jexcel.options.data[row][col] = txtValue;
                }
                if(col == 5)
                {
                    txtValue = numeral(tol_defective_qty).format('0.000');
                    $(cell).text(txtValue);
                    instance.jexcel.options.data[row][col] = txtValue;
                }
                if(col == 6)
                {
                    txtValue = numeral(defective_qty_replace).format('0.000');
                    $(cell).text(txtValue);
                    instance.jexcel.options.data[row][col] = txtValue;
                }
                if(col == 7)
                {
                    txtValue = numeral(tol_excess_qty).format('0.000');
                    $(cell).text(txtValue);
                    instance.jexcel.options.data[row][col] = txtValue;
                }
                if(col == 8)
                {
                    txtValue = numeral(tol_available_qty).format('0.000');
                    $(cell).text(txtValue);
                    instance.jexcel.options.data[row][col] = txtValue;
                }
                if(col == 9)
                {
                    $(cell).text(uom);
                    instance.jexcel.options.data[row][col] = uom;
                }
            }
        };

        shipmentOrderDetails_vm = new Vue({
            el: '#shipmentOrderClosure',
            mounted: function () {
                let spreadsheet = jexcel(this.$el, list);
                Object.assign(this, spreadsheet);
            },
        });
    }

    $('#getValues').click(function () {
        swalWithBootstrapButtons.fire(
            // *** CONFIRMATION MESSAGE *** //
            alertMessageFunction('confirmation_save')
        ).then(function (result) {
            if (result.value) {
                let in_house_qty = inHouseQty_vm.getData();
                let mi_issued_details = mateiralIssuedDetails_vm.getData();
                let shipment_order_details = shipmentOrderDetails_vm.getData();
                updateFunction(in_house_qty, mi_issued_details, shipment_order_details);
            }
            else if (result.dismiss === Swal.DismissReason.cancel) {
                // *** CANCELLED MESSAGE *** //
                swalWithBootstrapButtons.fire(
                    alertMessageFunction('cancelled')
                );
            }
        });
    });

    function updateFunction(in_house_qty, mi_issued_details, shipment_order_details) {
        let dataform = new FormData();
        dataform.append('enquiry_id', enquiry_id);
        dataform.append('reqId', reqId);
        dataform.append('in_house_qty', JSON.stringify(in_house_qty));
        dataform.append('mi_issued_details', JSON.stringify(mi_issued_details));
        dataform.append('shipment_order_details', JSON.stringify(shipment_order_details));

        let request = $.ajax({
            type: "POST",
            url: base_path + 'request/Bomrequest/updateOrderStockDetails',
            data: dataform,
            processData: false,
            contentType: false,
            cache: false,
            success: function (data) {
                // // *** SAVED MESSAGE *** //
                swalWithBootstrapButtons.fire(
                    alertMessageFunction('saved')
                ).then(okay => {
                    if(okay)
                    {
                        // window.location.href = base_path + 'request/Bomrequest/managementpurchaseindentapproval';
                    }
                });
            },
            error: function () {
                console.log("Error");
            }
        });
    }

    // *********************************************************************************************************************************** 
    // SAMPLE REQUEST ENDS HERE 
    // ***********************************************************************************************************************************
    
});