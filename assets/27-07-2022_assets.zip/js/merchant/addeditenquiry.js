function fnSaveEnquiry() {
    //try {
        var OrderEnqRefNo     = $("#frmOrderEnqRefNo").val();
        var EnquiryDate = $("#frmBasicEnqDate").val();
        var Styref = $("#frmBasicStyleRefNo").val();
        var StyDesc     = $("#frmBasicStyleDesc").val();
        var frmBasicMnote = $("#frmBasicMnote").val();
        var frmBasicEType = $("#frmBasicEType").val();
        var frmBasicMoE = $("#frmBasicMoE").val();
        var frmBasicBrand = $("#frmBasicBrand").val();
        var frmBasicBuyer = $("#frmBasicBuyer").val();
        var frmBasicPs = $("#frmBasicPs").val();
        var frmBasicCountry = $("#frmBasicCountry").val();
        var frmBasicQprice = $("#frmBasicQprice").val();
        var frmBasicBprice = $("#frmBasicBprice").val();
        var frmBasicCprice = $("#frmBasicCprice").val();
        var frmBasicCurrency = $("#frmBasicCurrency").val();
        var frmBasicPqty = $("#frmBasicPqty").val();
        var frmBasicRType = $("#frmBasicRType").val();

        var frmBasicISRany = $("#frmBasicISRany").val();

        var PriceQuotedFor = $("#frmPriceQuotedFor").val();
        
        var frmcombo   = $("#frmcombo").val();
        var frmComponents = $("#frmComponents").val();
        var frmShipmentDate = $("#frmShipmentDate").val();
        
        $('.form-control').css("border", "1px solid #cccccc");
        $('div.herr').text('');

        $(".requestTypeSelecting").change(function () {
            console.log(this.value);
        });

        if(jsTrim(OrderEnqRefNo) == "") {
            $('#ErrfrmOrderEnqRefNo').html("Enter Order / Enquiry Ref. No.");
            $('#frmOrderEnqRefNo').focus();
            $('#frmOrderEnqRefNo').css("border", "1px solid #B94A48");
            return false;
        }
        if(EnquiryDate == "") {
            $('#ErrfrmBasicEnqDate').html("Select Enquiry Date");
            $('#frmBasicEnqDate').focus();
            $('#frmBasicEnqDate').css("border", "1px solid #B94A48");
            return false;
        }
//        if(jsTrim(Styref) == "") {
//            $('#ErrfrmBasicStyleRefNo').html("Enter Style Ref. No. / Name");
//            $('#frmBasicStyleRefNo').focus();
//            $('#frmBasicStyleRefNo').css("border", "1px solid #B94A48");
//            return false;
//        }

        if(jsTrim(StyDesc) == "") {
            $('#ErrfrmBasicStyleDesc').html("Enter Style Description");
            $('#frmBasicStyleDesc').focus();
            $('#frmBasicStyleDesc').css("border", "1px solid #B94A48");
            return false;
        }
        if(frmBasicEType == "") {
            $('#ErrfrmBasicEType').html("Select Enquiry Type");
            $('#frmBasicEType').focus();
            $('#frmBasicEType').css("border", "1px solid #B94A48");
            return false;
        }
        if(frmBasicMoE == "") {
            $('#ErrfrmBasicMoE').html("Select Mode Of Enquiry");
            $('#frmBasicMoE').focus();
            $('#frmBasicMoE').css("border", "1px solid #B94A48");
            return false;
        }
        if(frmBasicBrand == "") {
            $('#ErrBasicBrand').html("Select Brand");
            $('#frmBasicBrand').focus();
            $('#frmBasicBrand').css("border", "1px solid #B94A48");
            return false;
        }
        if(frmBasicBuyer == "") {
            $('#ErrBasicBuyer').html("Select Buyer");
            $('#frmBasicBuyer').focus();
            $('#frmBasicBuyer').css("border", "1px solid #B94A48");
            return false;
        }
        if(frmBasicCountry == "") {
            $('#ErrfrmBasicCountry').html("Select Country");
            $('#frmBasicCountry').focus();
            $('#frmBasicCountry').css("border", "1px solid #B94A48");
            return false;
        }
//        if(jsTrim(frmBasicPqty) == "") {
//            $('#ErrfrmBasicPqty').html("Enter Total Order Qty.");
//            $('#frmBasicPqty').focus();
//            $('#frmBasicPqty').css("border", "1px solid #B94A48");
//            return false;
//        }
//        if(frmBasicPs == "") {
//            $('#ErrfrmBasicPs').html("Select Pcs. / Set");
//            $('#frmBasicPs').focus();
//            $('#frmBasicPs').css("border", "1px solid #B94A48");
//            return false;
//        }
//        if(frmBasicCurrency == 0) {
//            $('#ErrfrmBasicCurrency').html("Select Currency");
//            $('#frmBasicCurrency').focus();
//            $('#frmBasicCurrency').css("border", "1px solid #B94A48");
//            return false;
//        }
//        if(jsTrim(frmBasicCprice) == "") {
//            $('#ErrfrmBasicCprice').html("Enter Confirm Price");
//            $('#frmBasicCprice').focus();
//            $('#frmBasicCprice').css("border", "1px solid #B94A48");
//            return false;
//        }
        if(jsTrim(frmcombo) == "")
        {
            $('#Errfrmfrmcombo').html("Enter No.of Combo/Colour");
            $('#frmcombo').focus();
            $('#frmcombo').css("border", "1px solid #B94A48");
            return false;
        }
        if(jsTrim(frmComponents) == "")
        {
            $('#ErrfrmfrmComponents').html("Enter No.of Component");
            $('#frmComponents').focus();
            $('#frmComponents').css("border", "1px solid #B94A48");
            return false;
        }
        if(frmBasicRType == "") {
            $('#ErrfrmBasicRType').html("Select Request Type");
            $('#frmBasicRType').focus();
            $('#frmBasicRType').css("border", "1px solid #B94A48");
            return false;
        }
        if(PriceQuotedFor == "")
        {
            $('#ErrfrmPriceQuotedFor').html("Select Price Quoted For");
            $('#frmPriceQuotedFor').focus();
            $('#frmPriceQuotedFor').css("border", "1px solid #B94A48");
            return false;
        }

        var Parameters = "rfrom=1&sd="+encodeURIComponent(StyDesc)+"&styref="+encodeURIComponent(Styref)+"&mt="+encodeURIComponent(frmBasicMnote)+"&enqdt="+
            EnquiryDate+"&enquiryid="+GlbEnquiryId+"&os=1&et="+frmBasicEType+"&me="+frmBasicMoE+"&brn="+frmBasicBrand+"&byr="+frmBasicBuyer+"&ps="+frmBasicPs+"&conty="+
            frmBasicCountry+"&qp="+frmBasicQprice+"&bp="+frmBasicBprice+"&cp="+frmBasicCprice+"&crncy="+frmBasicCurrency+"&proq="+frmBasicPqty+
            "&resend=0&rt="+frmBasicRType+"&israny="+frmBasicISRany+"&orderenqrefno="+encodeURIComponent(OrderEnqRefNo)+"&pricequotedfor="+PriceQuotedFor+"&frmcombo="+ frmcombo +
            "&frmComponents=" +frmComponents + "&frmShipmentDate=" + frmShipmentDate;
        if (confirm("To confirm click OK, else CANCEL")) {
            MakeAsynPostRequest(base_path+'merchant/updateenquiry',Parameters,'json',fnSaveEnquiryRes);
            return false;
        }
        else {
            return false;
        }
//    } catch(e) {
//        alert(e);
//    }
}
var GlbInsertId = 0;
function fnSaveEnquiryRes(data) {
    if(data!='') {
        console.log(data,'data');
        if(data.errcode == '404') {
            fnCallSessionExpire();
            return false;
        } else if(data.errcode==-1) {
            $('#ErrBasicAccessories').html(data.msg);
            return false;
        } else if(data.errcode==1) {
            $("#addenqbut").remove();
            GlbInsertId = data.id;
            //console.log(GlbInsertId,'GlbInsertId');
            extraObj.startUpload();
            $("#frmBasicReqDT").text(data.dcreated);
            //console.log(extraObj,'extraObj');
            $("#divSuccessBasicInfoMsgparent").removeClass('hide');
            $("#divSuccessBasicInfoMsg").html("Enquiry has been sent successfully!");
        }
        let enquiryListPath = "merchant/orderEnquiryList";
        enquiryListPath = base_path+enquiryListPath;
        setTimeout(function() { 
            window.location.href = enquiryListPath;
        }, 1000);
    }
}

$(document).ready(function() {
    extraObj     = $("#uploadBusinessImg").uploadFile({
        dragDrop: true,
        multiple:true,
        url:base_path+'merchant/enqFileUpload',
        returnType: "json",
        fileName:"myFile",
        allowedTypes: allowedFileTypes,
        dynamicFormData:function () {
            return {'id':GlbInsertId};
        },
        autoSubmit:false
    });
    //console.log(extraObj,'extraObj INI');


        $("#frmBasicBrand").change(function () {
            // console.log($(this).val(), '$(this).val()');
            var BrnId = $(this).val();
            MakeAsynPostRequest(base_path + "merchant/getBuyerInfoByBrandId", "rFrom=1&id=" + BrnId, "json", function (data) {
                // console.log(data.buyerId, 'buyerId');
                if (data.buyerId != '')
                    $("#frmBasicBuyer").val(data.buyerId);
            });
        });
});




$(document).ready(function() {
    $("#submitAuthRequest").click(function () {
        $('#myModal').modal('show');
    });

    $("#submitRequest").click(function () {
        $(".herr").text('');
        try {
            // var pw = $("#frmPin").val();
            var one = $("#numberone").val();
            var two = $("#numbertwo").val();
            var three = $("#numberthree").val();
            var four = $("#numberfour").val();
            GlbAuthStatus = $("#frmBasicOrderStatus").val();

            var val = one+two+three+four;
            // console.log(val);
            if (jsTrim(one) == "" && jsTrim(two) == "" && jsTrim(three) == "" && jsTrim(four) == "") {
                $("#ErrfrmPin").text('Enter PIN');
                return false;
            }

            MakeAsynPostRequest(base_path + 'merchant/fnCheckPin', "rfrom=1&i=" + val + "&enqid=" + GlbEnquiryId + "&s=" +
                            GlbAuthStatus + "&ty=" + GlbIsrIor, 'json', fnAuthRes);
            return false;

            function fnAuthRes(data) {
                if (data != '') {
                    if (data.errcode == '404') {
                        fnCallSessionExpire();
                        return false;
                    } else if (data.errcode == '-1') {
                        $('#ErrfrmPin').text(data.msg);
                        return false;
                    } else if (data.errcode == '1') {
                        $('#myModal').modal('hide');
                        $("#divSuccessBasicInfoDiv").removeClass('hide');
                        $("#divSuccessBasicInfoMsg").text(data.msg);
                        
                        let swalWithBootstrapButtons = Swal.mixin({buttonsStyling: false});
                        swalWithBootstrapButtons.fire(
                            {
                                title: 'Are you sure want to Authorize ?',
                                type: 'warning',
                                showCancelButton: true,
                                scrollbarPadding: false,
                                confirmButtonText: 'Yes, do it!',
                                cancelButtonText: 'No, cancel!',
                                reverseButtons: true,
                                customClass: {'confirmButton': 'btn btn-green mx-2 px-3',  'cancelButton': 'btn btn-red mx-2 px-3'}
                            }
                        ).then(function(result) {
                            if (result.value) {
                                $('#myModal').modal('hide');
                                
                                let idValue = $('#enquiryFormId').val();
                                let orderStatus = 1;
                                let status = 1;
                                MakeAsynPostRequest(base_path + "merchant/submitAuthRequest", 
                                    "rFrom=1&id="+idValue+"&orderStatus="+orderStatus+"&status="+status, "json", function (data) {
                                    // console.log(data);
                                    if(data.statusCode == "200") {
                                        swalWithBootstrapButtons.fire({
                                            title: 'Saved!',text: data.message,type: 'success',
                                            icon: 'success',
                                            customClass: {'confirmButton': 'btn btn-info px-5'}
                                        }).then((result) => {
                                            let enquiryListPath = "merchant/orderEnquiryList";
                                            enquiryListPath = base_path+enquiryListPath;
                                            window.location.href = enquiryListPath;
                                        });
                                        
                                    }
                                    else if(data.statusCode == "203") {
                                        swalWithBootstrapButtons.fire({
                                            title: 'Saved!', text: data.message, type: 'success',
                                            icon: 'info',
                                            customClass: {'confirmButton': 'btn btn-info px-5'}
                                        }).then((result) => {
                                            let enquiryListPath = "merchant/orderEnquiryList";
                                            enquiryListPath = base_path+enquiryListPath;
                                            window.location.href = enquiryListPath;
                                        });
                                        
                                    }
                                    else {
                                        swalWithBootstrapButtons.fire({title: 'Error!',text: data.message,type: 'error',icon: 'error',customClass: {'confirmButton': 'btn btn-info px-5'}});
                                    }
                                });

                                
                            } 
                            else if (result.dismiss === Swal.DismissReason.cancel) {
                                $('#myModal').modal('hide');
                                swalWithBootstrapButtons.fire({
                                    title: 'Cancelled',
                                    text: 'Cancelled successfully.',
                                    type: 'error',
                                    icon: 'error',
                                    customClass: {'confirmButton': 'btn btn-secondary px-5'}
                                });
                            }
                        }); 
                    }
                }
            }

        } catch (e) {
            alert(e);
        }
    });

})

$(document).ready(function(){
    var href = location.href;
    var parts = href.split('/');
     //console.log(parts)
    var lastSegment = parts.pop() || parts.pop();
    var id = atob(decodeURIComponent(lastSegment));
    var segment = '';
    // local
    //segment = parts[6];
    // production
     segment = parts[4];

    if(lastSegment != 'addenquiry' && segment == 'addenquiry')
    {
        // console.log(lastSegment);
		return $.ajax({
			url: base_path+'merchant/getSeperateOrderEnquiryList',
			type:'POST',
            data: {"id": id},
			success:function(data){
				enquiryJSON = $.parseJSON(data);
                $("#enquiry_add_form input").prop("disabled", true);
                $("#enquiry_add_form select").prop("disabled", true);
                $("#enquiry_add_form textarea").prop("disabled", true);
                $("#frmBasicMnote").prop("disabled", true);

                $('#frmOrderEnqRefNo').val(enquiryJSON[0].orderenqrefno);
                var d = new Date(enquiryJSON[0].formattedDateCreated);
                var edate = ("0" + (d.getDate())).slice(-2) + '-' + ("0" + (d.getMonth() + 1)).slice(-2) + '-' + d.getFullYear();
                $('#frmBasicEnqDate').val(edate);
                $('#frmBasicStyleRefNo').val(enquiryJSON[0].stylenamerefno);
                $('#frmBasicStyleDesc').val(enquiryJSON[0].styledesc);
                $("#frmBasicEType").val(enquiryJSON[0].enquirytype).trigger("change");
                $("#frmBasicMoE").val(enquiryJSON[0].modeofenquiry).trigger("change");
                $("#frmBasicBrand").val(enquiryJSON[0].brandId).trigger("change");
                $('#frmBasicBuyer').val(enquiryJSON[0].buyerId);

                $("#frmBasicCountry").val(enquiryJSON[0].countryid).trigger("change");
                //$('#frmBasicPqty').val(enquiryJSON[0].total_comp);
                $('#frmBasicPqty').val(enquiryJSON[0].exporderqty).trigger("change");
                $("#frmBasicPs").val(enquiryJSON[0].pcsorset).trigger("change");
                $('#frmcombo').val(enquiryJSON[0].totalcombo);
                $('#frmComponents').val(enquiryJSON[0].totalcomponents);
                var shipmentdate = enquiryJSON[0].shipmentdate;
                if(shipmentdate != null)
                {
                    var sd = new Date(enquiryJSON[0].shipmentdate);
                    var sdate = ("0" + (sd.getDate())).slice(-2) + '-' + ("0" + (sd.getMonth() + 1)).slice(-2) + '-' + sd.getFullYear();
                    $('#frmShipmentDate').val(sdate);
                }
                else{
                    $('#frmShipmentDate').val('');
                }
                $("#frmPriceQuotedFor").val(enquiryJSON[0].pricequotedfor).trigger("change");
                $('#frmBasicQprice').val(enquiryJSON[0].quotedprice);
                $("#frmBasicCurrency").val(enquiryJSON[0].currency).trigger("change");
                $('#frmBasicBprice').val(enquiryJSON[0].buyerprice);
                $("#frmBuyerCurrency").val(enquiryJSON[0].currency).trigger("change");
                $('#frmBasicCprice').val(enquiryJSON[0].confirmprice);
                $("#frmConfirmCurrency").val(enquiryJSON[0].currency).trigger("change");
                $("#frmBasicRType").val(enquiryJSON[0].reqforisrior).trigger("change");
                let create_iso = new Date(enquiryJSON[0].datecreated);
                let cdate = create_iso.getDate();
                let month = create_iso.getMonth()+1;
                let year = create_iso.getFullYear();
                // Hours
                var hours = create_iso.getHours();
                // Minutes
                var minutes = "0" + create_iso.getMinutes();
                var ampm = hours >= 12 ? "PM":"AM";
                var datecreated = cdate + '-' + month + '-' + year + ' ' + hours + ':' + minutes.substr(-2) + ' ' + ampm;
                $("#frmBasicReqDT").val(datecreated);
                $("#frmmercentname").val(enquiryJSON[0].mer_name);
                $('#frmBasicISRany').val(enquiryJSON[0].isrrefany);
                $('#frmAuthoriaztionStatus').val(enquiryJSON[0].completestatus);
                $('#frmBasicMnote').val(enquiryJSON[0].merchantnote).trigger("change");
			},
			error: function() {
				console.log("Error");  
			}
		});
    }
});

$('#editEnable').on('click', function() {
    $("#enquiry_add_form input").prop("disabled", false);
    $("#enquiry_add_form select").prop("disabled", false);
    $("#enquiry_add_form textarea").prop("disabled", false);
    $("#frmBasicMnote").prop("disabled", false);
});