function fnSearchPort() {
    var PortName = $("#frmSrchPortName").val();
    var PortCity = $("#frmSrchPortCity").val();
    var PortCountry = $("#frmSrchPortCountry").val();
    var Status = $("#frmSrchPortStatus").val();
    GlbSearchParam = "rfrom=1&pn=" + PortName + "&s=" + Status + "&cty=" + PortCity + "&pcntry=" + PortCountry;
    $("#DivTotalCntResult").html('');
    MakeAsynPostRequest(base_path + GlbCompanyFdr + 'mport/manageport', GlbSearchParam, 'json', fnListPortRes);
}
function fnListPort() {
    GlbSearchParam = "rfrom=1";
    $("#DivTotalCntResult").html('');
    MakeAsynPostRequest(base_path + GlbCompanyFdr + 'mport/manageport', GlbSearchParam, 'json', fnListPortRes);
}
function fnListPortRes(data) {
    if (data != '') {
        if (data.errcode != undefined) {
            if (data.errcode == '404') {
                fnCallSessionExpire();
                return false;
            } else {
                var PageContent = '';
                if (data.cn > 0) {
                    ListCount = '<div style="font-weight:bold;">Number of Record(s) : ' + data.cn + '</div>';
                    if (data.ct > 0) {
                        $.each(data.re, function (index, value) {
                            PageContent = PageContent + '<tr>' +
                                '<td><input type="checkbox" class="allcbox" id="' + value.id + '"></td>' +
                                '<td>' +
                                '<a href="' + base_path + GlbCompanyFdr + 'mport/addedit/' + encodeURIComponent(base64_encode(value.id)) + '/">' + value.pn + '</a>' +
                                '</td>' +
                                '<td>' + value.cty + '</td>' +
                                '<td>' + value.pcntry + '</td>' +
                                '<td>' + value.s + '</td>' +
                                '<td>' + value.ub + '</td>' +
                                '<td>' + value.du + '</td>' +
                                '<td>' +
                                '<a href="' + base_path + GlbCompanyFdr + 'mport/addedit/' + encodeURIComponent(base64_encode(value.id)) + '/edit' + '">' +
                                '<i class="fa fa-edit"></i>&nbsp;Edit</a>' +
                                '</td>';
                            PageContent = PageContent + '</tr>';
                        });
                    }
                    $("#DivTotalCntResult").html(ListCount);
                } else {
                    PageContent = PageContent + '<tr><td colspan="6" class="pdl15 herr text-center" style="padding-left:10px;">No Records(s) found</td></tr>';
                    $("#DivTotalCntResult").html('');
                }
                if (data.pa != undefined) {
                    $("#ResPagination").html(base64_decode(data.pa));
                }
                $('tbody').empty();
                $('#tableList').append(PageContent);
            }
        }
    }
}
function fnPaginationPort(VarURL) {
    var Parameters = GlbSearchParam;
    $("#DivTotalCntResult").html('');
    MakeAsynPostRequest(VarURL, Parameters, 'json', fnListPortRes);
}
function fnSavePortInfo() {
    try {
        $('.form-control').css("border", "1px solid #cccccc");
        $('div.herr').html('');
        var ProfileFormData = false;
        var PortName = $("#frmBasicPortName").val();
        var PortCity = $("#frmBasicPortCity").val();
        var PortCountry = $("#frmBasicPortCountry").val();
        var Status = $("#frmBasicStatus").val();
        if (jsTrim(PortName) == "") {
            $('#ErrBasicPortName').text("Please fill the port name");
            $('#frmBasicPortName').focus();
            $('#frmBasicPortName').css("border", "1px solid #B94A48");
            return false;
        }
        if (jsTrim(PortCity) == "") {
            $('#ErrfrmBasicPortCity').text("Please fill the city");
            $('#frmBasicPortCity').focus();
            $('#frmBasicPortCity').css("border", "1px solid #B94A48");
            return false;
        }
        if (jsTrim(PortCountry) == "") {
            $('#ErrBasicPortCountry').text("Please fill the country");
            $('#frmBasicPortCountry').focus();
            $('#frmBasicPortCountry').css("border", "1px solid #B94A48");
            return false;
        }
        if (jsTrim(Status) == "") {
            $('#ErrBasicStatus').text("Please select the status");
            $('#frmBasicStatus').focus();
            $('#frmBasicStatus').css("border", "1px solid #B94A48");
            return false;
        }
        if (window.FormData) {
            ProfileFormData = new FormData();
            ProfileFormData.append("pn", PortName);
            ProfileFormData.append("cty", PortCity);
            ProfileFormData.append("pcntry", PortCountry);
            ProfileFormData.append("s", Status);
            ProfileFormData.append("id", GlbId);
        }
        $.ajax({
            url: base_path + GlbCompanyFdr + 'mport/updatePortInfo',
            data: ProfileFormData ? ProfileFormData : ObjForm.serialize(),
            cache: false,
            contentType: false,
            processData: false,
            type: 'POST',
            success: function (data, textStatus, jqXHR) {
                data = JSON.parse(data);
                fnSavePortRes(data);
            }
        });
        return false;
    } catch (e) {
        alert(e);
    }
}
function fnSavePortRes(data) {
    if (data != '') {
        if (data.errcode == '404') {
            fnCallSessionExpire();
            return false;
        } else if (data.errcode == -1) {
            $('#AnyOtherErr').text(data.msg);
            return false;
        } else if (data.errcode == 1) {
            GlbId = data.id;
            $("#divSuccessBasicInfoMsg").removeClass('hide');
            $("#divSuccessBasicInfoMsg").text("Updated successfully");
            fnRedirectPageTimeOut(base_path + GlbCompanyFdr + 'mport/addedit/' + data.eid);
        }
    }
}
function fnChangeStatusRes(data) {
    if (data != '') {
        if (data.errcode != undefined) {
            if (data.errcode == '404') {
                fnCallSessionExpire();
                return false;
            } else {
                fnSearchPort();
            }
        }
    }
}
$(document).ready(function () {
    $('#tableList').on('click', 'th.sortable', function () {
        var ReturnVal = commonTableSorting(this);
        GlbSortOrder = ReturnVal[1];
        GlbColumnId = ReturnVal[0];
        var PortName = $("#frmSrchPortName").val();
        var PortCity = $("#frmSrchPortCity").val();
        var PortCountry = $("#frmSrchPortCountry").val();
        var Status = $("#frmSrchPortStatus").val();
        GlbSearchParam = "rfrom=1&pn=" + PortName + "&s=" + Status + "&cty=" + PortCity + "&pcntry=" + PortCountry + "&columnId=" + GlbColumnId + "&sortorder=" + GlbSortOrder;
        MakeAsynPostRequest(base_path + GlbCompanyFdr + 'mport/manageport', GlbSearchParam, 'json', fnListPortRes);
    });
});
$('#btnChangeStatus').on('click', function () {
    var dropdownOpt = $('#frmItemStatus').val();
    if (dropdownOpt > 0) {
        var SewTypeIdObject = commonCheckbox();
        var checkBoxLength = SewTypeIdObject[1];
        var cboxObj = SewTypeIdObject[0];
        if (checkBoxLength == 0) {
            alert("Select Port");
        }
        if (checkBoxLength >= 1) {
            var companyid_json = JSON.stringify(cboxObj);
            if (confirm('Do you want to ' + GlbStatusForMaster[dropdownOpt] + ' this record?')) {
                GlbSearchParam = "rfrom=1&actDeact=" + dropdownOpt + "&cid=" + companyid_json;
                MakeAsynPostRequest(base_path + GlbCompanyFdr + 'mport/changemStatus', GlbSearchParam, 'json', fnChangeStatusRes);
            }
        }
    }
    else {
        alert('Select either ' + GlbStatusForMaster['1'] + ' or ' + GlbStatusForMaster['2']);
    }
});