var GlbSearchParam = '';
var GlbSortOrder = '';
var GlbColumnId = '';
function fnSearchPackingCode() {
    var PackingCode          				    = $("#frmSrchPackingCode").val();
    var Status          						= $("#frmSrchPackingCodeStatus").val();
    GlbSearchParam							    = "rfrom=1&pn="+PackingCode+"&s="+Status;
    $("#DivTotalCntResult").html('');
    MakeAsynPostRequest(base_path + GlbCompanyFdr + 'mpackingcode/managepackingcode', GlbSearchParam, 'json', fnListPackingCodeRes);
}

function fnListPackingCode() {
    GlbSearchParam								= "rfrom=1";
    $("#DivTotalCntResult").html('');
    MakeAsynPostRequest(base_path + GlbCompanyFdr + '/mpackingcode/managepackingcode', GlbSearchParam, 'json', fnListPackingCodeRes);
}

function fnListPackingCodeRes(data){
    if(data!=''){
        if(data.errcode!=undefined) {
            if(data.errcode == '404') {
                fnCallSessionExpire();
                return false;
            } else {
                var PageContent='';
                if(data.cn>0) {
                    ListCount	= '<div style="font-weight:bold;">Number of Record(s) : '+data.cn+'</div>';
                    if(data.ct>0) {
                        $.each(data.re,function(index,value){
                            PageContent = PageContent + '<tr><td><input type="checkbox" id="' + value.id + '" class="allcbox"></td>' +
                                '<td>' +
                                '<a href="' + base_path + GlbCompanyFdr + 'mpackingcode/addedit/' + encodeURIComponent(base64_encode(value.id)) + '/">' + value.n + '</a></td>' +
                                '<td>' + value.s + '</td><td>' + value.ub + '</td><td>' + value.du + '</td>' +
                                '<td>' +
                                '<a href="' + base_path + GlbCompanyFdr + 'mpackingcode/addedit/' + encodeURIComponent(base64_encode(value.id)) + '/edit' + '"><i class="fa fa-edit"></i>&nbsp;Edit</a></td>';
                            PageContent=PageContent+'</tr>';
                        });
                    }
                    $("#DivTotalCntResult").html(ListCount);
                } else {
                    PageContent	= PageContent+'<tr><td colspan="6" class="pdl15 herr text-center" style="padding-left:10px;">No Records(s) found</td></tr>';
                    $("#DivTotalCntResult").html('');
                }
                if(data.pa!=undefined) {
                    $("#ResPagination").html(base64_decode(data.pa));
                }
                $("tbody").empty();
                $("#tablepackingList").append(PageContent);
            }
        }
    }
}

function fnPaginationPackingCode(VarURL) {
    var Parameters = GlbSearchParam;
    $("#DivTotalCntResult").html('');
    MakeAsynPostRequest(VarURL, Parameters, 'json', fnListPackingCodeRes);
}
/*function fnDeletePackingCode(Id) {
    if(confirm("Are you want to delete this packing code?")) {
        var Parameters = "id="+Id;
        MakeAsynPostRequest(base_path+GlbCompanyFdr+'mpackingcode/delPackingCodeInfo',Parameters,'json',fnDeletePackingCodeRes);
    }
}

function fnDeletePackingCodeRes(data){
    if(data!=''){
        if(data.errcode!=undefined) {
            if(data.errcode == '404') {
                fnCallSessionExpire();
                return false;
            } else {
                fnSearchPackingCode();
            }
        }
    }
}*/

function fnSavePackingCodeInfo() {
    try {
        $('.form-control').css("border", "1px solid #cccccc");
        $('div.herr').text('');
        var ProfileFormData							= false;
        var PackingCode     						= $("#frmBasicPackingCode").val();
        var Status        							= $("#frmBasicStatus").val();
        if(jsTrim(PackingCode)== ""){
            $('#ErrBasicPackingCode').text("Please fill the packing code");
            $('#frmBasicPackingCode').focus();
            $('#frmBasicPackingCode').css("border", "1px solid #B94A48");
            return false;
        }
        if(jsTrim(Status)== ""){
            $('#ErrBasicStatus').text("Please select the status");
            $('#frmBasicStatus').focus();
            $('#frmBasicStatus').css("border", "1px solid #B94A48");
            return false;
        }
        if (window.FormData){
            ProfileFormData								= new FormData();
            ProfileFormData.append("pn",PackingCode);
            ProfileFormData.append("s",Status);
            ProfileFormData.append("id",GlbId);
        }
        $.ajax({
            url 		: base_path+GlbCompanyFdr+'mpackingcode/updatePackingCodeInfo',
            data        : ProfileFormData ? ProfileFormData : ObjForm.serialize(),
            cache       : false,
            contentType : false,
            processData : false,
            type        : 'POST',
            success     : function(data, textStatus, jqXHR){
                data = JSON.parse(data);
                fnSavePackingCodeRes(data);
            }
        });
        return false;
    } catch(e) {
        alert(e);
    }
}

function fnSavePackingCodeRes(data){
    if(data!=''){
        if(data.errcode == '404') {
            fnCallSessionExpire();
            return false;
        } else if(data.errcode==-1){
            $('#ErrBasicPackingCode').text(data.msg);
            return false;
        } else if(data.errcode==1){
            GlbId       = data.id;
            $("#divSuccessBasicInfoMsg").removeClass('hide');
            $("#divSuccessBasicInfoMsg").text("Updated successfully");
            fnRedirectPageTimeOut(base_path+GlbCompanyFdr+'mpackingcode/addedit/'+data.eid);
        }
    }
}

$( document ).ready(function() {
    $('#tablepackingList').on('click', 'th.sortable', function () {
        var ReturnVal							    = commonTableSorting(this);
        GlbSortOrder	  							= ReturnVal[1];
        GlbColumnId									= ReturnVal[0];
        var PackingCode          				    = $("#frmSrchPackingCode").val();
        var Status          						= $("#frmSrchPackingCodeStatus").val();
        GlbSearchParam = "rfrom=1&pn=" + PackingCode + "&s=" + Status + "&columnId=" + GlbColumnId + "&sortorder=" + GlbSortOrder;
        MakeAsynPostRequest(base_path + GlbCompanyFdr + 'mpackingcode/managepackingcode', GlbSearchParam, 'json', fnListPackingCodeRes);
    });
});
$('#btnChangeStatus').on('click', function () {
    var dropdownOpt = $('#frmItemStatus').val();
    if (dropdownOpt > 0) {
        var SewTypeIdObject = commonCheckbox();
        var checkBoxLength = SewTypeIdObject[1];
        var cboxObj = SewTypeIdObject[0];
        if (checkBoxLength == 0) {
            alert("Select Packing Code");
        }
        if (checkBoxLength >= 1) {
            var companyid_json = JSON.stringify(cboxObj);
            if (confirm('Do you want to ' + GlbStatusForMaster[dropdownOpt] + ' this record?')) {
                GlbSearchParam = "rfrom=1&actdeactFabType=" + dropdownOpt + "&cid=" + companyid_json;
                MakeAsynPostRequest(base_path + GlbCompanyFdr + 'mpackingcode/changemStatus', GlbSearchParam, 'json', fnChangeStatusRes);
            }
        }
    }
    else {
        alert('Select either ' + GlbStatusForMaster['1'] + ' or ' + GlbStatusForMaster['2']);
    }
});

function fnChangeStatusRes(data) {
    if(data!='') {
        if(data.errcode!=undefined) {
            if(data.errcode == '404') {
                fnCallSessionExpire();
                return false;
            } else {
                fnSearchPackingCode();
            }
        }
    }
}