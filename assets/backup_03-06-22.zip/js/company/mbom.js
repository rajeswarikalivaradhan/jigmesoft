var GlbSearchParam = '';
var GlbSortOrder = '';
var GlbColumnId = '';
function fnSearchBom() {
    var frmBasicBomName = $("#frmSrchBomName").val();
    var Blend = $("#frmSrchBomBlend").val();
    var Content = $("#frmSrchBomContent").val();
    var Material = $("#frmSrchBomMaterial").val();
    var Articletype = $("#frmSrchBomArtType").val();
    var SplReq = $("#frmSrchBomSplReq").val();
    var Status = $("#frmSrchBomStatus").val();
    GlbSearchParam = "rfrom=1&i=" + frmBasicBomName + "&b=" + Blend + "&c=" + Content + "&arttype=" +
        Articletype + "&m=" + Material + "&spl=" + SplReq + "&s=" + Status + "&columnId=" + GlbColumnId + "&sortorder=" + GlbSortOrder;
    $("#DivTotalCntResult").html('');
    MakeAsynPostRequest(base_path + GlbCompanyFdr + 'mbom/manage', GlbSearchParam, 'json', fnListBomRes);
}
function fnListBom() {
    GlbSearchParam = "rfrom=1";
    $("#DivTotalCntResult").html('');
    MakeAsynPostRequest(base_path + GlbCompanyFdr + 'mbom/manage', GlbSearchParam, 'json', fnListBomRes);
}
function fnListBomRes(data) {
    console.log(data, 'd');
    console.log(data.re, 'dd');
    if (data != '') {
        if (data.errcode != undefined) {
            if (data.errcode == '404') {
                fnCallSessionExpire();
                return false;
            } else {
                var PageContent = '';
                if (data.cn > 0) {
                    ListCount = '<div style="font-weight:bold;">Number of Record(s) : ' + data.cn + '</div>';
                    if (data.ct > 0) {
                        $.each(data.re, function (index, value) {
                            PageContent = PageContent + '<tr><td><input type="checkbox" class="allcbox" id="' + value.id + '"></td>' +
                                '<td><a href="' + base_path + GlbCompanyFdr + 'mbom/addedit/' + encodeURIComponent(base64_encode(value.id)) + '">' + value.i + '</a></td>' +
                                '<td>' + value.b + '</td>' +
                                '<td>' + value.c + '</td>' +
                                '<td>' + value.m + '</td>' +
                                '<td>' + value.spl + '</td>' +
                                '<td>' + value.arttype + '</td>' +
                                '<td>' + value.s + '</td><td>' + value.ub + '</td>' +
                                '<td>' + value.du + '</td>' +
                                '<td><a href="' + base_path + GlbCompanyFdr + 'mbom/addedit/' + encodeURIComponent(base64_encode(value.id)) + '/edit' + '"><i class="fa fa-edit"></i>&nbsp;Edit</a></td>';
                            PageContent = PageContent + '</tr>';
                        });
                    }
                    $("#DivTotalCntResult").html(ListCount);
                } else {
                    PageContent = PageContent + '<tr><td colspan="6" class="pdl15 herr text-center" style="padding-left:10px;">No Records(s) found</td></tr>';
                    $("#DivTotalCntResult").html('');
                }
                if (data.pa != undefined) {
                    $("#ResPagination").html(base64_decode(data.pa));
                }
                $('tbody').empty();
                $('#mBomList').append(PageContent);
            }
        }
    }
}
function fnPaginationBom(VarURL) {
    var Parameters = GlbSearchParam;
    $("#DivTotalCntResult").html('');
    MakeAsynPostRequest(VarURL, Parameters, 'json', fnListBomRes);
}
function fnSaveBomInfo() {
    try {
        $('.form-control').css("border", "1px solid #cccccc");
        $('div.herr').text('');
        var ProfileFormData = false;
        var frmBasicBomName = $("#frmBasicBomName").val();
        var Blend = $("#frmBasicBlend").val();
        var Content = $("#frmBasicContent").val();
        var Arttype = $("#frmBasicArticleType").val();
        var SpceialRequest = $("#frmBasicSplReq").val();
        var frmBasicMat = $("#frmBasicMat").val();
        var Status = $("#frmBasicStatus").val();
        if (jsTrim(frmBasicBomName) == "") {
            $('#ErrfrmBasicBomName').text("Please fill the Item Description");
            $('#frmBasicBomName').focus();
            $('#frmBasicBomName').css("border", "1px solid #B94A48");
            return false;
        }
        if (jsTrim(Blend) == "") {
            $('#ErrfrmBasicBlend').text("Please fill the Blend (%)");
            $('#frmBasicBlend').focus();
            $('#frmBasicBlend').css("border", "1px solid #B94A48");
            return false;
        }
        if (jsTrim(Content) == "") {
            $('#ErrfrmBasicContent').text("Please fill the Content");
            $('#frmBasicContent').focus();
            $('#frmBasicContent').css("border", "1px solid #B94A48");
            return false;
        }
        if (jsTrim(frmBasicMat) == "") {
            $('#ErrfrmBasicMat').text("Please fill Material");
            $('#frmBasicMat').focus();
            $('#frmBasicMat').css("border", "1px solid #B94A48");
            return false;
        }
        if (jsTrim(SpceialRequest) == "") {
            $('#ErrfrmBasicSplReq').text("Please fill Special Request");
            $('#frmBasicSplReq').focus();
            $('#frmBasicSplReq').css("border", "1px solid #B94A48");
            return false;
        }
        if (Arttype == "") {
            $('#ErrfrmBasicArticleType').text("Please select article type");
            $('#frmBasicArticleType').focus();
            $('#frmBasicArticleType').css("border", "1px solid #B94A48");
            return false;
        }

        if (jsTrim(Status) == "") {
            $('#ErrBasicStatus').text("Please select the status");
            $('#frmBasicStatus').focus();
            $('#frmBasicStatus').css("border", "1px solid #B94A48");
            return false;
        }
        if (window.FormData) {
            ProfileFormData = new FormData();
            ProfileFormData.append("i", frmBasicBomName);
            ProfileFormData.append("b", Blend);
            ProfileFormData.append("cn", Content);
            ProfileFormData.append("arttype", Arttype);
            ProfileFormData.append("spl", SpceialRequest);
            ProfileFormData.append("ma", frmBasicMat);
            ProfileFormData.append("s", Status);
            ProfileFormData.append("id", GlbId);
        }
        $.ajax({
            url: base_path + GlbCompanyFdr + 'mbom/updateInfo',
            data: ProfileFormData ? ProfileFormData : ObjForm.serialize(),
            cache: false,
            contentType: false,
            processData: false,
            type: 'POST',
            success: function (data, textStatus, jqXHR) {
                data = JSON.parse(data);
                fnSaveBomRes(data);
            }
        });
        return false;
    } catch (e) {
        alert(e);
    }
}
function fnSaveBomRes(data) {
    if (data != '') {
        if (data.errcode == '404') {
            fnCallSessionExpire();
            return false;
        } else if (data.errcode == -1) {
            $('#AnyOtherErr').text(data.msg);
            return false;
        } else if (data.errcode == 1) {
            GlbId = data.id;
            $("#divSuccessBasicInfoMsg").removeClass('hide');
            $("#divSuccessBasicInfoMsg").text("Updated successfully!");
            fnRedirectPageTimeOut(base_path + GlbCompanyFdr + 'mbom/addedit/' + data.eid);
        }
    }
}
function fnChangeStatusRes(data) {
    if (data != '') {
        if (data.errcode != undefined) {
            if (data.errcode == '404') {
                fnCallSessionExpire();
                return false;
            } else {
                fnSearchBom();
            }
        }
    }
}
$('#mBomList').on('click', 'th.sortable', function () {
    var ReturnVal = commonTableSorting(this);
    GlbSortOrder = ReturnVal[1];
    GlbColumnId = ReturnVal[0];
    var frmBasicBomName = $("#frmSrchBomName").val();
    var Status = $("#frmSrchBomStatus").val();
    GlbSearchParam = GlbSearchParam + "&columnId=" + GlbColumnId + "&sortorder=" + GlbSortOrder;
    MakeAsynPostRequest(base_path + GlbCompanyFdr + 'mbom/manage', GlbSearchParam, 'json', fnListBomRes);
});
$('#btnChangeStatus').on('click', function () {
    var dropdownOpt = $('#frmItemStatus').val();
    if (dropdownOpt > 0) {
        var SewTypeIdObject = commonCheckbox();
        var checkBoxLength = SewTypeIdObject[1];
        var cboxObj = SewTypeIdObject[0];
        if (checkBoxLength == 0) {
            alert("Select Item description");
        }
        if (checkBoxLength >= 1) {
            var companyid_json = JSON.stringify(cboxObj);
            var frmBasicBomName = $("#frmSrchBomName").val();
            var Status = $("#frmSrchBomStatus").val();
            if (confirm('Do you want to ' + GlbStatusForMaster[dropdownOpt] + ' this record?')) {
                GlbSearchParam = "rfrom=1&actdeactFabType=" + dropdownOpt + "&cid=" + companyid_json;
                MakeAsynPostRequest(base_path + GlbCompanyFdr + 'mbom/changemStatus', GlbSearchParam, 'json', fnChangeStatusRes);
            }
        }
    }
    else {
        alert('Select either ' + GlbStatusForMaster['1'] + ' or ' + GlbStatusForMaster['2']);
    }
});