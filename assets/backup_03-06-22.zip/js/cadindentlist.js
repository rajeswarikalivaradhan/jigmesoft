

    $(document).ready(function() {

        var reqRequestJSON;
        $.when(getReqRequestList()).done(function(){
            dispDetails(reqRequestJSON);		
        });

        $(document).ajaxStart(function(a){
            $.LoadingOverlay("show",{image: "../assets/img/fullpage.gif"});
        });
        $(document).ajaxStop(function(){
            $.LoadingOverlay("hide");
        });

        function getReqRequestList()
        {
            return $.ajax({
                url: base_path+'company/mcaduser/getcadIndentlist',
                type:'POST',
                success:function(data){
                    reqRequestJSON = $.parseJSON(data);
                },		
                error: function() {
                    console.log("Error");  
                }
            });
        }

        function dispDetails(reqRequestJSON)
        {
            if ( $.fn.DataTable.isDataTable('#mCadQueueList') ) {
                $('#mCadQueueList').DataTable().destroy();
            }
            var i = 1;
            $('#mCadQueueList tbody').empty();	
            $("#mCadQueueList").dataTable({
                "aaData": reqRequestJSON,
                "aaSorting": [],
                "aoColumns": [		
                    {
                        "mDataProp": function(data, type, full, meta) {
                            return '<input type="checkbox" class="allcbox" id="'+data.request_id+'">';
                        }
                    },
                    { "mDataProp": "isriorcode" },	
                    { "mDataProp": "brandname" },	
                    { "mDataProp": "ref_queue_no" },
                    // { "mDataProp": "requirement" },
                    {
                        "mDataProp": function ( data, type, full, meta) {
                            return 'CAD';
                        }
                    },
                    {
                        "mDataProp": function ( data, type, full, meta) {
                            return '<a class="bold" href="' + base_path +'request/Cadrequest/cadIndentDetails/'+ encodeURIComponent(btoa(data.enquiry_id)) + '/reqId/' + encodeURIComponent(btoa(data.request_id)) + '/miId/' + encodeURIComponent(btoa(data.mi_id)) + '">' + data.cad_ref_no + '</a>';
                        }
                    },
                    // { 
                    //     "mDataProp": function ( data, type, full, meta) {
                    //         if(data.cad_dept == "OUTSIDE VENDOR") {
                    //             return 'External';
                    //         }
                    //         else {
                    //             return 'Internal';
                    //         }
                    //     }
                    // },							
                    { 
                        "mDataProp": function ( data, type, full, meta) {
                            return data.req_date;
                        }
                    },							
                    {
                        "mDataProp": function ( data, type, full, meta) {
                            return data.cutoff_date;
                        }
                    },
                    // { "mDataProp": "merchant_name" },
                    { "mDataProp": "auth_type" },
                    { "mDataProp": "auth_name" },
                    { 
                        "mDataProp": function ( data, type, full, meta) {
                            // var CADSTATUS = ['PENDING', 'RECEIVED', 'DISCREPANCY', 'MISSING'];
                            if (data.status == 0)
                            return '<span class="text-light knOrangeColor bg-dark"><strong>PENDING</strong></span>';
                            else
                            return '<span class="text-light knGreenColor bg-dark"><strong>ISSUED - PART</strong></span>';
                        }
                    },
                    {
                        "mDataProp": function ( data, type, full, meta) {
                            var d = new Date(data.recent_update); 
                            var time = d.toLocaleString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
                            var dFormat = ("0" + (d.getDate())).slice(-2) + '/' + ("0" + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear() + ' ' + time;
                            return dFormat;
                        }
                    },
                    {
                        "mDataProp": function ( data, type, full, meta) {
                            if(data.flag == "1")
                            return 'Active';
                            else if(data.flag == "2")
                            return 'Inactive';
                            else
                            return 'Active';
                        }
                    },							
                ]  						
            });
        }
    });