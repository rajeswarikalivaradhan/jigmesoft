$(document).ready(function() {

    var reqRequestJSON;
	$.when(getReqRequestList()).done(function(){
		dispDetails(reqRequestJSON);		
	});

    $(document).ajaxStart(function(a){
        $.LoadingOverlay("show",{image: "../assets/img/fullpage.gif"});
    });
    $(document).ajaxStop(function(){
        $.LoadingOverlay("hide");
    });

	function getReqRequestList()
	{
		return $.ajax({
			url: base_path+'company/mpurchaseuser/getBomPurchaseSentList',
			type:'POST',
			success:function(data){
				reqRequestJSON = $.parseJSON(data);
			},		
			error: function() {
				console.log("Error");  
			}
		});
	}

	function dispDetails(reqRequestJSON)
	{
		if ( $.fn.DataTable.isDataTable('#bomPurchaseReceivedListTbl') ) {
		  $('#bomPurchaseReceivedListTbl').DataTable().destroy();
		}

        var i = 1;

		$('#bomPurchaseReceivedListTbl tbody').empty();	
		$("#bomPurchaseReceivedListTbl").dataTable({
            "aaData": reqRequestJSON,
            "aaSorting": [],
			"aoColumns": [	
                {
                    "mDataProp": function(data, type, full, meta) {
                        return '<input type="checkbox" class="allcbox" id="'+data.request_id+'">';
                    }
                },	
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return data.isriorcode;
					}
				},		
				{ "mDataProp": "brandname" },	
				{ 
					"mDataProp": function ( data, type, full, meta) {
						// if(data.type == 1)
						// return 'CAD';
						// else if(data.type == 2)
						// return 'SAMPLE';
						// else if(data.type == 3)
						// return 'BOM Article - 1';
						// else if(data.type == 4)
						// return 'BOM Article - 2';
						// else
						return data.request_for;
					}
				},	
                {
					"mDataProp": function ( data, type, full, meta) {
                        if(data.request_for == "P.I.APPROVAL")
						{
							if(data.type == 3)
							{
								return 'BOM Article - 1';
							}
							else {
								return 'BOM Article - 2';
							}
						}
                        else if(data.request_for == "PAYMENT")
                        return data.payment_requirement;
					}
				},
                {
					"mDataProp": function ( data, type, full, meta) {
                        return data.vendorname;
					}
				},
				{ 
					"mDataProp": function ( data, type, full, meta) {
						return '<a class="bold" href="' + base_path +'request/Bomrequest/purchaseindentdetails' + '/' + encodeURIComponent(btoa(data.enquiry_id)) + '/reqId/' + encodeURIComponent(btoa(data.request_id)) + '">' + data.pi_ref_queue_no + '</a>';
					}
				},
				{ 
					"mDataProp": function ( data, type, full, meta) {
                        // var d = new Date(data.cutoff_date); 
                        // var time = d.toLocaleString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
                        // var dFormat = ("0" + (d.getDate())).slice(-2) + '/' + ("0" + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear();
						return data.pi_dt;
					}
				},{ 
					"mDataProp": function ( data, type, full, meta) {
                        return data.cutoff_date;
					}
				},
				{ "mDataProp": "exp_dod" },
				{ 
					"mDataProp": function ( data, type, full, meta) {
                        // if(data.mgmt_approval == '0' || data.mgmt_approval == '')
                        return '<span class="text-light knOrangeColor bg-dark"><strong>PENDING</strong></span>';
                        // else if(data.mgmt_approval == '2')
                        // return '<span class="text-light knRedColor bg-dark"><strong>APPROVED</strong></span>';
                        // else
                        // return '<span class="text-light knGreenColor bg-dark"><strong>APPROVED</strong></span>';
					}
				},						
				{ 
					"mDataProp": function ( data, type, full, meta) {
                        var d = new Date(data.log); 
                        var time = d.toLocaleString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
                        var dFormat = ("0" + (d.getDate())).slice(-2) + '/' + ("0" + (d.getMonth() + 1)).slice(-2) + '/' + d.getFullYear() + ' ' +time;
						return dFormat;
					}
				},					
				{ 
					"mDataProp": function ( data, type, full, meta) {
                        if(data.flag == "1")
                        return 'Active';
                        else if(data.flag == "0")
                        return 'Inactive';
                        else
                        return 'Active';
					}
				},										
			]  						
		});
	}

});