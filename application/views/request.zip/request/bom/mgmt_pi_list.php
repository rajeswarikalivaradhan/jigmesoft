<?php $this->load->view(CNFCOMPANY . 'template/pageheader'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/datatables.min.css">
<body class="sidebar-mini skin-black wysihtml5-supported sidebar-collapse">
<div class="wrapper">
    <?php $this->load->view(CNFCOMPANY . 'template/templateheader'); ?>
    <aside class="main-sidebar">
        <?php $this->load->view(CNFCOMPANY . 'template/templateleftmenu'); ?>
    </aside>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="col-md-6">
                <h1 style="margin: 0; font-size: 20px; font-weight: 600">PURCHASE DEPT. - BOM PURCHASE REQUEST RECEIVED LIST</h1>
            </div>
            <div class="col-md-6" style="padding-bottom: 10px">
                <div class="col-md-6"></div>
                <div class="col-md-6 updateBtnInList">
                    <div class="col-md-8">
                        <select name="frmItemStatus" title="activate / deactivate" id="frmItemStatus" class="form-control" style="">
                            <option value="">Select</option>
                            <?php
                            $ArrStatus = unserialize(ARRSTATUS);
                            foreach ($ArrStatus as $key => $status) {
                                echo '<option value="'.$key.'">'.$status.'</option>';
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-2" style="padding-right: 0; float: right;">
                        <input type="button" name="btnChangeStatus" id="btnChangeStatus" class="btn btn-info pull-right" value="Update">
                    </div>
                </div>

            </div>
        </section>
        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-info">
                        <div class="box-body no-padding">
                            <table id="bomPurchaseReceivedListTbl" class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th id="0">WIP Ref. No. </th>
                                        <th id="1">Brand</th>
                                        <th id="2">Requirement</th>
                                        <th id="5">P.I. Appl. Cutoff<br> Date & Time</th>
                                        <th id="4">P.I. Approved<br> Date & Time</th>
                                        <th id="2">P.I. No.</th>
                                        <th id="3">Vendor Name</th>
                                        <th id="3">Supply Lead Time</th>
                                        <th id="6">Expected Date Of <br>Delivery</th>
                                        <th id="11">Current <br>Status</th>
                                        <th id="9">Recent Update </th>
                                        <th id="10">Status</th>
                                    </tr>
                                </thead>
                            </table>
                        </div><!-- /.box-body -->
                    </div><!-- /.box -->
                </div><!-- /.col -->
            </div>
        </section>
    </div><!-- /.content-wrapper -->
    <?php $this->load->view(CNFCOMPANY . 'template/templatefooter'); ?>
    <div class="control-sidebar-bg"></div>
</div><!-- ./wrapper -->
<script src="<?php echo base_url(); ?>assets/js/loadingoverlay.min.js"></script>
<script src="<?php echo base_url();?>assets/js/datatables.min.js"></script>
<script src="<?php echo base_url();?>assets/custom/request/bom/mgmt_pi_list.js"></script>
<script>
    $(document).ajaxStart(function (a) {
        $.LoadingOverlay("show", {image: base_path + "assets/img/fullpage.gif"});
    });
    $(document).ajaxStop(function () {
        $.LoadingOverlay("hide");
    });

    // var dataTbl = '';
    // $(document).ready(function() {
    //     dataTbl = $('#bomPurchaseReceivedListTbl').DataTable({
    //         "processing": true,
    //         "serverSide": true,
    //         "ajax": {
    //             "url": "<?php echo base_url(CNFCOMPANY.'mpurchaseuser/purchasereceivedlist')?>",
    //             "type": "POST",
    //             "data": {"rfrom":1}
    //         },
    //         'columnDefs': [{
    //             'targets': [0], // column index (start from 0)
    //             'orderable': false, // set orderable false for selected columns
    //         }],
    //         "order": [11,"desc"]
    //     });
    // });

    // $('#btnChangeStatus').on('click', function () {
    //     var dropdownOpt = $('#frmItemStatus').val();
    //     console.log(dropdownOpt,'dropdownOpt');
    //     var SelectedIdObject = commonCheckbox();
    //     var checkBoxLength   = SelectedIdObject[1];
    //     if (dropdownOpt > 0) {
    //         if (checkBoxLength >= 1) {
    //             var idJson = JSON.stringify(SelectedIdObject[0]);
    //             var StatusText = "Deactivate";
    //             if (dropdownOpt == 1) {
    //                 var StatusText = "Activate";
    //             }
    //             if (confirm('Do you want to ' + StatusText + ' this records?')) {
    //                 MakeAsynPostRequest(base_path + 'dashboard/changeAllListActiveStatus', 'id=' + idJson + '&cs=' + dropdownOpt+
    //                     '&tblname=kn_allrequest', 'json', function (data) {
    //                     console.log(data, 'data');
    //                     dataTbl.ajax.url("<?php echo base_url('purchaseuser/purchasereceivedlist') ?>").load();
    //                 });
    //             }
    //         }
    //     }
    //     else {
    //         alert('Select a option');
    //     }
    //     if(checkBoxLength == 0) {
    //         alert('Select a record');
    //     }
    // });
</script>
<?php $this->load->view(CNFCOMPANY . 'template/pagefooter'); ?>