<?php $this->load->view(CNFCOMPANY.'template/pageheader');?>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/datatables.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/bootstrap-datepicker.min.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/select2.min.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/uploadfile-order.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css"  />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/wip.css" />

<!-- *********************** JEXCEL CSS LOADS HERE ************************-->
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/css/jexcelNew/jspreadsheet.css" />
<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/css/jexcelNew/jsuites.css" />

<!-- *********************** JEXCEL SCRIPTS LOADS HERE ************************-->
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/ajax.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/vue.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jexcelNew/jexcel.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jexcelNew/jsuites.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jexcel/numeral.min.js"></script>

<!-- *************** CUSTOM STYLE HERE ********* -->
<style>
table.table.tbl-procs-border {
    margin-bottom: 0;
}
</style>

<body class="hold-transition layout-top-nav">
    <div class="wrapper">
        <?php $this->load->view(CNFCOMPANY . 'template/templateheader'); ?>
        <div class="content px-4">
            <!-- *********************** ORDER PROCESSING START HERE ************************-->
            <?php $this->load->view(CNFREQUEST . 'request_orderprocessing.php'); ?>
            <!-- *********************** ORDER PROCESSING ENDS HERE ************************-->

            <div class="card border-0">
                <div class="card-header p-3 border-0 bgc-white tbl-head mb-1">
                    <div class="card-title text-white f-14 text-500">SAMPLE REQUEST</div>
                </div>
                <div id="sampleRequest"></div>
            </div>
            
            <div class="card border-0 mar-t-3">
                <div class="card-header p-3 border-0 bgc-white tbl-head mb-1">
                    <div class="card-title text-white f-14 text-500">ATTACHMENT & REFERENCE DETAILS</div>
                </div>
                <div id="attachReference"></div>
            </div>
            
            <div class="col-12 text-right pr-3 py-3">                
                <a class="btn btn-info btn-sm mar-l-5rem" id="saveRequestDetails">SAVE REQUEST DETAILS</a>
            </div>

            <!-- *********************** MATERIAL INDENT START HERE ************************-->

            <!-- CAD MATERIAL INDENT STARTS HERE -->

            <form class="row no-rad-form add-form-mar mar-t-3" id="">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Material Indent Ref. No.
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" id="cad_ref" name="cad_ref" class="form-control" value="" readonly placeholder="Auto Update">
                                <div class="herr" id="err_cad_ref"></div>
                            </div>
                        </div>
                    </div>   
                    
                    <div class="col-sm-3">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Issue to Department
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <select class="cus-sel form-control js-example-basic-single" id="cad_deprt" name="cad_deprt">
                                    <option value="" disabled hidden>Select</option>
                                    <option value="REGULAR">REGULAR</option>
                                    <option value="PRIORITY">PRIORITY</option>
                                    <option value="HIGH PRIORITY">HIGH PRIORITY</option>
                                    <option value="IMMEDIATE">IMMEDIATE</option>
                                </select>
                                <div class="herr" id="err_cad_deprt"></div>
                            </div>
                        </div>
                    </div>  

                    <div class="col-sm-3">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Request Date & Time
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" id="cad_req_date" name="cad_req_date" class="form-control date" value="" placeholder="Auto Update">
                                <div class="herr" id="err_cad_req_date"></div>
                            </div>
                        </div>
                    </div>   
                    
                    <div class="col-sm-3">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Cutoff Date & Time
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" id="cad_cutoff_date" name="cad_cutoff_date" class="form-control date" value="" placeholder="Auto Update">
                                <div class="herr" id="err_cad_cutoff_date"></div>
                            </div>
                        </div>
                    </div>   
                </div>
            </form>

            <div class="card border-0 mar-t-3">
                <div class="card-header p-3 border-0 bgc-white tbl-head mb-1">
                    <div class="card-title text-white f-14 text-500">CAD - MATERIAL INDENT</div>
                </div>
                <div id="cadMaterialIndent"></div>
            </div>
            
            <!-- CAD MATERIAL INDENT ENDS HERE -->

            <!-- FABRIC MATERIAL INDENT STARTS HERE -->

            <form class="row no-rad-form add-form-mar mar-t-3" id="">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Material Indent Ref. No.
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" id="fab_ref" name="fab_ref" class="form-control" readonly value="" placeholder="Auto Update">
                                <div class="herr" id="err_fab_ref"></div>
                            </div>
                        </div>
                    </div>   
                    
                    <div class="col-sm-3">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Issue to Department
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <select class="cus-sel form-control js-example-basic-single mgmt" id="fab_dept" name="fab_dept">
                                    <option value="" disabled hidden>Select</option>
                                    <option value="REGULAR">REGULAR</option>
                                    <option value="PRIORITY">PRIORITY</option>
                                    <option value="HIGH PRIORITY">HIGH PRIORITY</option>
                                    <option value="IMMEDIATE">IMMEDIATE</option>
                                </select>
                                <!-- <input type="text" id="fab_dept" name="fab_dept" class="form-control" readonly value="" placeholder="Auto Update"> -->
                                <div class="herr" id="err_fab_dept"></div>
                            </div>
                        </div>
                    </div>  

                    <div class="col-sm-3">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Request Date & Time
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" id="fab_req_date" name="fab_req_date" readonly class="form-control date" value="" placeholder="Auto Update">
                                <div class="herr" id="err_fab_req_date"></div>
                            </div>
                        </div>
                    </div>   
                    
                    <div class="col-sm-3">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Cutoff Date & Time
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" id="fab_cuttoff_date" name="fab_cuttoff_date" class="form-control date" readonly value="" placeholder="Auto Update">
                                <div class="herr" id="err_fab_cuttoff_date"></div>
                            </div>
                        </div>
                    </div>   
                </div>
            </form>
            
            <div class="card border-0 mar-t-3">
                <div class="card-header p-3 border-0 bgc-white tbl-head mb-1">
                    <div class="card-title text-white f-14 text-500">FABRIC - MATERIAL INDENT</div>
                </div>
                <div id="fabricMaterialIndent"></div>
            </div>
            
            <!-- FABRIC MATERIAL INDENT ENDS HERE -->
            
            <!-- BOM MATERIAL INDENT STARTS HERE -->

            <form class="row no-rad-form add-form-mar mar-t-3" id="">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Material Indent Ref. No.
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" id="bom_ref" name="bom_ref" class="form-control" readonly value="" placeholder="Auto Update">
                                <div class="herr" id="err_bom_ref"></div>
                            </div>
                        </div>
                    </div>   
                     
                    <div class="col-sm-3">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Issue to Department
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <select class="cus-sel form-control js-example-basic-single mgmt" id="bom_dept" name="bom_dept">
                                    <option value="" disabled hidden>Select</option>
                                    <option value="REGULAR">REGULAR</option>
                                    <option value="PRIORITY">PRIORITY</option>
                                    <option value="HIGH PRIORITY">HIGH PRIORITY</option>
                                    <option value="IMMEDIATE">IMMEDIATE</option>
                                </select>
                                <!-- <input type="text" id="bom_dept" name="bom_dept" class="form-control" readonly value="" placeholder="Auto Update"> -->
                                <div class="herr" id="err_bom_dept"></div>
                            </div>
                        </div>
                    </div>  

                    <div class="col-sm-3">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Request Date & Time
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" id="bom_req_date" name="bom_req_date" class="form-control date" readonly value="" placeholder="Auto Update">
                                <div class="herr" id="err_bom_req_date"></div>
                            </div>
                        </div>
                    </div>   
                    
                    <div class="col-sm-3">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Cutoff Date & Time
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" id="bom_cuttoff_date" name="bom_cuttoff_date" class="form-control date" value="" readonly placeholder="Auto Update">
                                <div class="herr" id="err_bom_cuttoff_date"></div>
                            </div>
                        </div>
                    </div>   
                </div>
            </form>

            <div class="card border-0 mar-t-3">
                <div class="card-header p-3 border-0 bgc-white tbl-head mb-1">
                    <div class="card-title text-white f-14 text-500">BOM - MATERIAL INDENT</div>
                </div>
                <div id="bomMaterialIndent"></div>
            </div>

            <!-- BOM MATERIAL INDENT ENDS HERE -->
            
            <!-- *********************** MATERIAL INDENT ENDS HERE ************************-->
            <form class="row no-rad-form add-form-mar mar-t-3" id="reqOrderProcessingForm">
                <div class="row">
                    <!-- First Column -->
                    <div class="col-sm-4">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Request Type
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <select class="cus-sel form-control js-example-basic-single" id="req_type" name="req_type">
                                    <option value="" disabled hidden>Select</option>
                                    <option value="REGULAR">REGULAR</option>
                                    <option value="PRIORITY">PRIORITY</option>
                                    <option value="HIGH PRIORITY">HIGH PRIORITY</option>
                                    <option value="IMMEDIATE">IMMEDIATE</option>
                                </select>
                                <div class="herr" id="err_req_type"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Request Date & Time
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" id="req_date" name="req_date" class="form-control" readonly value="" placeholder="Auto Update">
                                <div class="herr" id="err_req_date"></div>
                            </div>

                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                Cutoff Date & Time
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" id="cutoff_date" name="cutoff_date" class="form-control date" placeholder="Free Select" value="">
                                <div class="herr" id="err_cutoff_date"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Merchant Note
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <textarea id="merchant_note" name="merchant_note" class="form-control h-90" placeholder="Free Text"></textarea>
                                <div class="herr" id="err_merchant_note"></div>
                            </div>
                        </div>
                    </div>

                    <!-- Second Column -->
                    <div class="col-sm-4">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Authorization Status
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control mgmt" id="auth_status" name="auth_status" autocomplete="off" value="" placeholder="Free Text">
                                <div class="herr" id="err_auth_status"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Authorization Type
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control mgmt" id="auth_type" name="auth_type" autocomplete="off" value="" placeholder="Free Text">
                                <div class="herr" id="err_auth_type"></div>
                            </div>

                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                Authorized By
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control mgmt" id="auth_by" name="auth_by" autocomplete="off" value="" placeholder="Free Text">
                                <div class="herr" id="err_auth_by"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Authorized Date & Time
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control mgmt" id="auth_date" name="auth_date" autocomplete="off" value="" placeholder="Free Text">
                                <div class="herr" id="err_auth_date"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Management Remarks
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control mgmt" id="mgmt_remark" name="mgmt_remark" autocomplete="off" value="" placeholder="Free Text">
                                <div class="herr" id="err_mgmt_remark"></div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Third Column -->
                    <div class="col-sm-4">
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Request Status
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control mgmt" id="req_status" name="req_status" autocomplete="off" value="" placeholder="Free Text">
                                <div class="herr" id="err_req_status"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>Assigned SAMPLE Queue No.
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control mgmt" id="queue_no" name="queue_no" value="" placeholder="Free Text">
                                <div class="herr" id="err_queue_no"></div>
                            </div>

                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                Q. No. Assigned Date & Time
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <input type="text" class="form-control mgmt" id="que_assign_date" name="que_assign_date" value="" placeholder="Free Text">
                                <div class="herr" id="err_que_assign_date"></div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-4 col-form-label text-sm-right pr-0">
                                <label for="id-form-field-focus-1" class="mb-0">
                                    <span class="mandatory">*</span>SAMPLE Dept. Remarks
                                </label>
                            </div>
                            <div class="col-sm-8">
                                <textarea rows="5" id="dep_remarks" name="dep_remarks" class="form-control h-90 mgmt" placeholder="Free Text"></textarea>
                                <div class="herr" id="err_dep_remarks"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 pr-3 py-3">
                        <label class="cus-label"> Attachment </label>
                        <div id="bom1ImageUpload" class="pdt10"></div>
                    </div>

                    <div class="col-12 text-right pr-3 py-3">                
                        <a class="btn btn-info btn-sm mar-l-5rem" id="saveasdraft">SAVE AS DRAFT</a>
                        <a class="btn btn-info btn-sm mar-l-5rem" id="getValues">SAVE</a>
                    </div>
                </div>
            </form>
        </div>

        

        <?php $this->load->view(CNFCOMPANY . 'template/templatefooter'); ?>
        <div class="control-sidebar-bg"></div>
    </div>
    <!-- <script src="<?php echo base_url();?>assets/js/datatables.min.js"></script> -->
    <?php $this->load->view(CNFCOMPANY . 'template/pagefooter'); ?>
    <script>
        var enquiry_id = <?php echo $VarEnqId; ?>;
    </script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.uploadfile.min.js?s=<?php echo str_rand(5) ?>"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/loadingoverlay.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/ace/node_modules/sweetalert2/dist/sweetalert2.all.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/custom/request/sample/sample.js">
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/custom/datepair.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/select2.min.js"></script>

    <script>
        $(document).ready(function() {

            $(".mgmt").prop('disabled', true);

            function matchStart(params, data) {
                params.term = params.term || '';
                if (data.text.toUpperCase().indexOf(params.term.toUpperCase()) == 0) {
                    return data;
                }
                return false;
            }

            $('.date').datepicker({
                'format': 'dd-mm-yyyy',
                'autoclose': true,
                'orientation': "bottom",
            }).datepicker("setDate",'today');

            $('.js-example-basic-single').select2({
                placeholder: "Select",
                matcher: function(params, data) {
                    return matchStart(params, data);
                },
            });

            $('b[role="presentation"]').hide();
            $('.select2-selection__arrow').append('<span class="arrow-select2-ji"><span>');
            
        });
    </script>